#include "JFunciones.h"
#include "Login.h"
#include <iostream>
#include <windows.h>
#include "LoginJ.h"
#include <string>
#define Tab "\t\t\t\t\t\t"


#define color SetConsoleTextAttribute
void dibujar();
bool verificarCI(string CI);
using namespace std;

int main()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int fiesta, eleccion1, roll;
    string CI, password, name;
    do {
        system("cls");
        color(hConsole, 4);
        dibujar();
        color(hConsole, 7);
        cout << endl;
        cout << Tab << "-------------------------------" << endl;
        cout << Tab << "Inicio de sesión: " << endl;
        cout << Tab << "-------------------------------" << endl;
        cout << Tab << "1. Registrarse" << endl;
        cout << Tab << "2. Iniciar sesión" << endl;
        cout << endl;
        cout << Tab << "Elija la opción: ";
        cin >> eleccion1;

        if (eleccion1 == 1 || eleccion1 == 2) {
            loginJ(eleccion1);
        }
    } while (eleccion1 == 3 || eleccion1==1 || eleccion1==0);
    system("cls");
    color(hConsole, 4);
    dibujar();
    color(hConsole, 7);
    cout << endl;
    cout << Tab << "-------------------------------" << endl;
    cout << Tab << "Eventos Disponibles" << endl;
    cout << Tab << "-------------------------------" << endl;
    cout <<Tab<< "1.Boda" << endl;
    cout <<Tab<< "2.Graduacion" << endl;
    cout <<Tab<< "3.Cumpleanios" << endl;
    cout << Tab << "Elija su evento: ";
    cin >> fiesta;
    musica(fiesta);
    
}

