#pragma once
// JFunciones.h
#ifndef JFunciones_H  // Directiva de inclusion multiple
#define JFunciones_H


void musica(int fiesta);

#endif // FUNCIONES_H