
#ifndef LoginJ_H  // Directiva de inclusion multiple
#define LoginJ_H
#include <string>
using namespace std;

void loginJ(int &eleccion1);


#endif // Login_H